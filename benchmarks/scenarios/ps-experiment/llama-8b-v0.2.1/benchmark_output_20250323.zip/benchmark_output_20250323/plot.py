import os
import pandas as pd
import matplotlib.pyplot as plt

QPS_RANGE = [0.1, 0.5, 0.9, 1.3, 1.7, 2.1, 2.5, 2.9, 3.3, 3.7, 4.1]

experiments = [
    {
        "prefix": "aibrix_naive_7_output",
        "label": "aibrix w/o cache v0.7.0",
        "color": "blue",
        "marker": "x",
    },
    {"prefix": "naive_output", "label": "Native K8S", "color": "orange", "marker": "v"},
    {"prefix": "ps_naive_output", "label": "PS naive", "color": "black", "marker": "d"},
    {
        "prefix": "aibrix_high_low_output",
        "label": "AIBrix w/ cache v0.6.1",
        "color": "red",
        "marker": "D",
    },
    {
        "prefix": "ps_stack_high_low_output",
        "label": "PS High-Low",
        "color": "green",
        "marker": "<",
    },
    {
        "prefix": "ps_stack_low_high_output",
        "label": "PS Low-High",
        "color": "brown",
        "marker": ">",
    },
]


def load_ttft_results(prefix):
    qpses = []
    avg_ttfts = []

    for qps in QPS_RANGE:
        file = f"{prefix}_{round(qps, 1)}.csv"
        if not os.path.exists(file):
            continue
        df = pd.read_csv(file)
        if "ttft" not in df.columns:
            continue
        ttft_vals = df["ttft"].dropna().tolist()
        if ttft_vals:
            qpses.append(round(qps, 1))
            avg_ttfts.append(sum(ttft_vals) / len(ttft_vals))

    return qpses, avg_ttfts


plt.figure(figsize=(10, 6))

for exp in experiments:
    qpses, ttfts = load_ttft_results(exp["prefix"])
    print(f"{exp['label']} TTFT:", ttfts)
    plt.plot(
        qpses,
        ttfts,
        label=exp["label"],
        marker=exp["marker"],
        color=exp["color"],
        linewidth=2,
        markersize=8,
    )

plt.xlim(left=0)
plt.ylim(top=10)
plt.xlabel("QPS")
plt.ylabel("Average Time to First Token (s)")
plt.title("Average Time to First Token vs QPS")
plt.legend()
plt.grid(True, linestyle="--", alpha=0.5)
plt.tight_layout()
plt.savefig("figure.png")
plt.show()
